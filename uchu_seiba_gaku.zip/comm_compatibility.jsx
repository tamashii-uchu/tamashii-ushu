import { useState } from "react";

const TYPES = ["風", "流星", "星", "太陽", "火", "虹", "大地", "惑星", "海", "光", "銀河", "月"];

const TEAMS = {
  フロント: ["惑星", "流星", "光", "太陽"],
  クリエイト: ["火", "風", "大地", "銀河"],
  サポート: ["海", "虹", "星", "月"],
};

const TEAM_COLORS = {
  フロント: "#C9A84C",
  クリエイト: "#8B7355",
  サポート: "#6B8E8E",
};

const TYPE_EMOJI = {
  風: "🌬️", 流星: "☄️", 星: "⭐", 太陽: "☀️",
  炎: "🔥", 虹: "🌈", 大地: "🌍", 惑星: "🪐",
  海: "🌊", 光: "✨", 銀河: "🌌", 月: "🌙",
};

const RELATIONS = [
  { steps: 1, name: "心地よい間柄", desc: "適度な距離・友達", color: "#7BB8B0" },
  { steps: 2, name: "深い共鳴の仲", desc: "本音でぶつかれる・真の親友", color: "#C9A84C" },
  { steps: 3, name: "互いを高め合う仲", desc: "緊張・刺激を受け合う", color: "#B87333" },
  { steps: 4, name: "利害が一致する仲", desc: "win-win", color: "#8B9E6B" },
  { steps: 5, name: "運命的に出会う仲", desc: "不思議な縁で引き寄せ合う", color: "#9B6B9B" },
  { steps: 6, name: "成長をもたらす仲", desc: "正反対だからこそ学ぶ", color: "#8B7355" },
];

function getTeam(type) {
  for (const [team, members] of Object.entries(TEAMS)) {
    if (members.includes(type)) return team;
  }
  return null;
}

function getRelation(typeA, typeB) {
  const idxA = TYPES.indexOf(typeA);
  const idxB = TYPES.indexOf(typeB);
  if (idxA === -1 || idxB === -1) return null;
  const diff = Math.abs(idxA - idxB);
  const steps = Math.min(diff, 12 - diff);
  if (steps === 0) return { steps: 0, name: "同じタイプ", desc: "鏡のような関係・自分と同じ魂の性質", color: "#C9A84C" };
  return RELATIONS.find(r => r.steps === steps) || null;
}

function TypeCard({ type, selected, onClick }) {
  const team = getTeam(type);
  const isSelected = selected === type;
  return (
    <button
      onClick={() => onClick(type)}
      style={{
        background: isSelected ? "#2C2C2C" : "white",
        border: `2px solid ${isSelected ? "#C9A84C" : "#E8D5A0"}`,
        borderRadius: 12,
        padding: "10px 8px",
        cursor: "pointer",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 4,
        transition: "all 0.2s",
        transform: isSelected ? "scale(1.05)" : "scale(1)",
      }}
    >
      <span style={{ fontSize: 22 }}>{TYPE_EMOJI[type]}</span>
      <span style={{
        fontSize: 15,
        fontWeight: "bold",
        color: isSelected ? "#C9A84C" : "#2C2C2C",
      }}>{type}</span>
      <span style={{
        fontSize: 9,
        color: TEAM_COLORS[team],
        background: isSelected ? "rgba(201,168,76,0.15)" : "#FDFAF4",
        borderRadius: 4,
        padding: "1px 5px",
      }}>{team}</span>
    </button>
  );
}

function RelationResult({ typeA, typeB }) {
  const relation = getRelation(typeA, typeB);
  const teamA = getTeam(typeA);
  const teamB = getTeam(typeB);
  const sameTeam = teamA === teamB;

  if (!relation) return null;

  return (
    <div style={{
      background: "white",
      border: `2px solid ${relation.color}`,
      borderRadius: 16,
      padding: 24,
      marginTop: 20,
      textAlign: "center",
    }}>
      {/* Types display */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 16, marginBottom: 20 }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 32 }}>{TYPE_EMOJI[typeA]}</div>
          <div style={{ fontSize: 18, fontWeight: "bold", color: "#2C2C2C" }}>{typeA}</div>
          <div style={{ fontSize: 10, color: TEAM_COLORS[teamA] }}>{teamA}チーム</div>
        </div>
        <div style={{ fontSize: 24, color: "#C9A84C" }}>✦</div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 32 }}>{TYPE_EMOJI[typeB]}</div>
          <div style={{ fontSize: 18, fontWeight: "bold", color: "#2C2C2C" }}>{typeB}</div>
          <div style={{ fontSize: 10, color: TEAM_COLORS[teamB] }}>{teamB}チーム</div>
        </div>
      </div>

      {/* Divider */}
      <div style={{ height: 1, background: "#E8D5A0", margin: "16px 0" }} />

      {/* Relation */}
      <div style={{
        display: "inline-block",
        background: relation.color + "20",
        border: `1px solid ${relation.color}`,
        borderRadius: 20,
        padding: "4px 16px",
        fontSize: 11,
        color: relation.color,
        marginBottom: 8,
        fontWeight: "bold",
      }}>
        軌道距離 {relation.steps === 0 ? "0" : relation.steps}つ
      </div>

      <div style={{ fontSize: 22, fontWeight: "bold", color: "#2C2C2C", marginBottom: 6 }}>
        {relation.name}
      </div>
      <div style={{ fontSize: 14, color: "#888", marginBottom: 16 }}>
        {relation.desc}
      </div>

      {/* Same team note */}
      {sameTeam && (
        <div style={{
          background: "#FDFAF4",
          border: "1px solid #E8D5A0",
          borderRadius: 8,
          padding: "8px 12px",
          fontSize: 12,
          color: "#8B7355",
        }}>
          🌟 同じ{teamA}チーム — 似た思考・価値観を持つ間柄
        </div>
      )}
      {!sameTeam && (
        <div style={{
          background: "#FDFAF4",
          border: "1px solid #E8D5A0",
          borderRadius: 8,
          padding: "8px 12px",
          fontSize: 12,
          color: "#8B7355",
        }}>
          💫 {teamA}チーム × {teamB}チーム — 異なるエネルギーが交わる
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [typeA, setTypeA] = useState(null);
  const [typeB, setTypeB] = useState(null);
  const [step, setStep] = useState(1); // 1: select A, 2: select B, 3: result

  const handleSelectA = (type) => {
    setTypeA(type);
    setTypeB(null);
    setStep(2);
  };

  const handleSelectB = (type) => {
    if (type === typeA) return;
    setTypeB(type);
    setStep(3);
  };

  const reset = () => {
    setTypeA(null);
    setTypeB(null);
    setStep(1);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "#FDFAF4",
      fontFamily: "'Hiragino Kaku Gothic Pro', 'Yu Gothic', sans-serif",
      padding: "0 0 40px",
    }}>
      {/* Header */}
      <div style={{
        background: "#2C2C2C",
        padding: "20px 20px 16px",
        textAlign: "center",
      }}>
        <div style={{ fontSize: 10, color: "#C9A84C", letterSpacing: 4, marginBottom: 6 }}>
          TAMASHII UCHU GAKU
        </div>
        <div style={{ fontSize: 22, color: "white", fontWeight: "bold", letterSpacing: 2 }}>
          魂宇宙学
        </div>
        <div style={{ fontSize: 12, color: "#C9A84C", marginTop: 4 }}>
          コミュニケーションタイプ 相性診断
        </div>
      </div>

      <div style={{ maxWidth: 480, margin: "0 auto", padding: "0 16px" }}>

        {/* Step indicator */}
        <div style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          gap: 8,
          padding: "16px 0",
        }}>
          {[1, 2, 3].map(s => (
            <div key={s} style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div style={{
                width: 28, height: 28, borderRadius: "50%",
                background: step >= s ? "#C9A84C" : "#E8D5A0",
                color: step >= s ? "white" : "#C9A84C",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 12, fontWeight: "bold",
              }}>{s}</div>
              {s < 3 && <div style={{ width: 30, height: 1, background: step > s ? "#C9A84C" : "#E8D5A0" }} />}
            </div>
          ))}
        </div>

        {/* Step 1: Select type A */}
        <div style={{
          background: "white",
          borderRadius: 16,
          padding: 20,
          border: "1px solid #E8D5A0",
          marginBottom: 12,
          opacity: step === 1 ? 1 : 0.7,
        }}>
          <div style={{ fontSize: 13, color: "#C9A84C", fontWeight: "bold", marginBottom: 12 }}>
            ✦ STEP 1 — Aさんのタイプを選ぶ
          </div>
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(4, 1fr)",
            gap: 8,
          }}>
            {TYPES.map(type => (
              <TypeCard key={type} type={type} selected={typeA} onClick={handleSelectA} />
            ))}
          </div>
        </div>

        {/* Step 2: Select type B */}
        {step >= 2 && (
          <div style={{
            background: "white",
            borderRadius: 16,
            padding: 20,
            border: "1px solid #E8D5A0",
            marginBottom: 12,
          }}>
            <div style={{ fontSize: 13, color: "#C9A84C", fontWeight: "bold", marginBottom: 12 }}>
              ✦ STEP 2 — Bさんのタイプを選ぶ
            </div>
            <div style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, 1fr)",
              gap: 8,
            }}>
              {TYPES.map(type => (
                <TypeCard
                  key={type}
                  type={type}
                  selected={typeB}
                  onClick={type === typeA ? () => {} : handleSelectB}
                />
              ))}
            </div>
            {typeA && (
              <div style={{ fontSize: 11, color: "#aaa", marginTop: 8, textAlign: "center" }}>
                ※ {typeA}（Aさん）と同じタイプは選べません
              </div>
            )}
          </div>
        )}

        {/* Step 3: Result */}
        {step === 3 && typeA && typeB && (
          <>
            <RelationResult typeA={typeA} typeB={typeB} />
            <button
              onClick={reset}
              style={{
                display: "block",
                width: "100%",
                marginTop: 16,
                padding: "12px",
                background: "transparent",
                border: "1px solid #C9A84C",
                borderRadius: 10,
                color: "#C9A84C",
                fontSize: 14,
                cursor: "pointer",
                fontFamily: "inherit",
              }}
            >
              もう一度診断する
            </button>
          </>
        )}

        {/* Team legend */}
        <div style={{
          marginTop: 20,
          background: "white",
          borderRadius: 12,
          padding: 16,
          border: "1px solid #E8D5A0",
        }}>
          <div style={{ fontSize: 11, color: "#C9A84C", fontWeight: "bold", marginBottom: 10 }}>
            ✦ チーム構成
          </div>
          {Object.entries(TEAMS).map(([team, members]) => (
            <div key={team} style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
              <div style={{
                fontSize: 10, color: TEAM_COLORS[team],
                border: `1px solid ${TEAM_COLORS[team]}`,
                borderRadius: 4, padding: "1px 6px", minWidth: 80, textAlign: "center",
              }}>
                {team}チーム
              </div>
              <div style={{ fontSize: 12, color: "#555" }}>
                {members.map(t => TYPE_EMOJI[t] + t).join("　")}
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
